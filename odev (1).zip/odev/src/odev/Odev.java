package odev;

import java.util.ArrayList;

class canli implements Comparable<canli>{

    private String ad;
    private int yas;
    ArrayList<virus> kVirusler;

    public canli(String ad, int yas) {
        this.ad = ad;
        this.yas = yas;

    }

    public int compareTo(canli canliObj) {
        if (this instanceof insan && canliObj instanceof insan) {
            return 1;
        } else if (this instanceof karincayiyen && canliObj instanceof karincayiyen) {
            return 1;
        } else if (this instanceof karinca && canliObj instanceof karinca) {
            return 1;
        } else {
            return 0;
        }

    }

    public void hastalıkKap(ArrayList<virus> virusler) {

        for (int i = 0; i < virusler.size(); i++) {//verilen virusler dizisinde kViruslerde olmayan bir virus varsa kViruse dizisine bunu ekliyorum.
            if (!kVirusler.contains(virusler.get(i))) {
                if (virusler.get(i).hastaEdiyormu(this)) {//hasta ediyor  mu
                    virus yenivirus = virusler.get(i);

                    int sayac = 0;
                    int toplamvirusbulasmamiktari = 0;//kolaylık olsun diye burada tutuyorum.
                    for (int j = 0; j < virusler.size(); j++) {//j yi normalde i den başlatabilridim ama toplamvirusbulasmamiktarina ihtiyacım var.ve burada olmayan virusden dizide kaç tane oldugunu bulmak için kullanıyorum
                        if (virusler.get(i) == yenivirus) {

                            sayac++;
                        }
                        toplamvirusbulasmamiktari += virusler.get(i).bulasmaMiktari;

                    }
                    if (sayac == 1) {
                        yenivirus.bulasmaMiktari = virusler.get(i).bulasmaMiktari;//bundan emin değilim.-bulasma miktarı değişmemeli demiş-

                    } else {
                        int ortalama = toplamvirusbulasmamiktari / virusler.size();

                        virusler.get(i).bulasmaMiktari = ortalama;

                    }
                    this.kVirusler.add(yenivirus);

                }

            }
            /*else {//daha önce var ise
             int enbuyuktoplam=0;
             int bolen=virusler.size()+kVirusler.size();
                
             for (int j = 0; j < virusler.size(); j++) {
             enbuyuktoplam+=virusler.get(i).bulasmaMiktari;
                    
             }
                
             for (int j = 0; j < kVirusler.size(); j++) {
                    
             enbuyuktoplam+=kVirusler.get(i).bulasmaMiktari;
             }
             int ort=enbuyuktoplam/bolen;
                
             for (int j = 0; j < kVirusler.size(); j++) {
             kVirusler.get(i).bulasmaMiktari=ort;//
             }
            
             BURANIN SIKINTISI HOCA YENİ NESNENİN BULASMA MİKTARI ORTALAMA OLARAK ALINIR DEMİŞ LAKİN VİRUSLERİN HEPSİ CANLI KİŞİSİNDE OLACAGINDAN YENİ VİRUS DE 
             OLUSMAYCAKTIR BU DURUMDA BULASMA MİKTARI HAKKINDA BİR DEĞİŞİKLİK YAPILSA YAPILSA HER VİRUSUN BULASMA MİKTARINI ARTTIRMAK OLABİLİR
             */

        }

    }

    public void hastalıkKap(canli[] canlilar) {

    }

    public String getAdi() {
        return ad;
    }

    public void setAdi(String ad) {
        this.ad = ad;
    }

    public int getYas() {
        return yas;
    }

    public void setYas(int yas) {
        this.yas = yas;
    }

    public ArrayList<virus> getKVirusler() {
        return kVirusler;
    }

    public void setKVirusler(ArrayList<virus> kVirusler) {

        kVirusler = new ArrayList<virus>();

        this.kVirusler = kVirusler;
    }

    public void hastalıkKapv2(ArrayList<canli> canlilar) {

        ArrayList<virus> yeni = new ArrayList<virus>();
        int i = 0;

        while (i != canlilar.size()) {
            for (int j = 0; j < canlilar.get(i).kVirusler.size(); j++) {//tüm canlıların tüm hastalıklarını eger hasta ediyorsa this canlısına enfekte edecegiz
                if (!this.kVirusler.contains(canlilar.get(i).kVirusler.get(j))) {//eger bu virus this canlısında  yok ise;

                    virus yenivirus = new virus(canlilar.get(i).kVirusler.get(j));

                    if (canlilar.get(i).kVirusler.get(j).hastaEdiyormu(this)) {//ve hasta edebiliyor ise
                        int toplambulasmamik = 0;
                        int sayac = 0;
                        for (int k = 0; k < canlilar.size(); k++) {

                            if (canlilar.get(k).kVirusler.contains(yenivirus)) {//burada yeni virusden kaç tane canlıda var onu bulucaz ama contains metodunu kullanamayız çunku virusun kacıncı indisde oldugunu bilmemiz gerekiyor.
                                int a = kVirusler.lastIndexOf(yenivirus);//kacıncı indis de oldugunu buluyorum
                                toplambulasmamik += canlilar.get(k).kVirusler.get(a).bulasmaMiktari;//k.canlıdaki a.indisindeki virüsün bulasma miktarşnı elde ediyorum.
                                sayac++;

                            }
                        }
                        if (sayac == 1) {
                            yenivirus.bulasmaMiktari = canlilar.get(i).kVirusler.get(j).bulasmaMiktari;

                        } else if (sayac != 1) {
                            int ort = toplambulasmamik / sayac;
                            yenivirus.bulasmaMiktari = ort;

                        }

                    }
                    this.kVirusler.add(yenivirus);

                }

            }
            /*else {//daha önce var ise
             int enbuyuktoplam=0;
             int bolen=virusler.size()+kVirusler.size();
                
             for (int j = 0; j < virusler.size(); j++) {
             enbuyuktoplam+=virusler.get(i).bulasmaMiktari;
                    
             }
                
             for (int j = 0; j < kVirusler.size(); j++) {
                    
             enbuyuktoplam+=kVirusler.get(i).bulasmaMiktari;
             }
             int ort=enbuyuktoplam/bolen;
                
             for (int j = 0; j < kVirusler.size(); j++) {
             kVirusler.get(i).bulasmaMiktari=ort;//
             }
            
             ****Burada da aynı durum söz konosu****
             BURANIN SIKINTISI HOCA YENİ NESNENİN BULASMA MİKTARI ORTALAMA OLARAK ALINIR DEMİŞ LAKİN VİRUSLERİN HEPSİ CANLI KİŞİSİNDE OLACAGINDAN YENİ VİRUS DE 
             OLUSMAYCAKTIR BU DURUMDA BULASMA MİKTARI HAKKINDA BİR DEĞİŞİKLİK YAPILSA YAPILSA HER VİRUSUN BULASMA MİKTARINI ARTTIRMAK OLABİLİR...
             */

            i++;

        }

    }

}

class insan extends canli {

    String meslek;
    canli[] canlilar;

    public insan(String ad, int yas, String meslek) {

        super(ad, yas);
        this.meslek = meslek;
    }

    @Override
    public void hastalıkKapv2(ArrayList<canli> canlılar) {

        ArrayList<canli> yeni = new ArrayList<canli>();
        yeni.addAll(canlılar);

        int i = 0;

        while (canlilar[i] != null) {
            if (canlılar.contains(canlilar[i])) {//dizimizdeki canlı eger verilen canlılar dizisinde var ise onu yeni olusturudugum listeden siliicem
                int konum = canlılar.indexOf(canlilar[i]);
                yeni.remove(konum);//elde ettiğim indeksde ki degeri siliyorum

            }
            i++;

        }//döngü bittiğinde de yeni methodumu cagırıyorum yeni canlılar listem ile
        // this.hastalıkKap(yeni);//****BURADA HOCA GUNCELLENECEK OLAN METODU YANLIS YAZMIS.

    }

}

class karincayiyen extends canli {

    public karincayiyen(String ad, int yas) {
        super(ad, yas);
    }

    public void karincaYe(ArrayList<karinca> karincalar) {

        int i = 0;

        while (i != karincalar.size()) {
            for (int j = 0; j < karincalar.get(i).kVirusler.size(); j++) {
                if (!this.kVirusler.contains(karincalar.get(i).kVirusler.get(j))) {

                    virus yeni = new virus(karincalar.get(i).kVirusler.get(j));
                    //yeni.bulasmamiktarı gibi degerler burada belirtilebilir.
                    this.kVirusler.add(yeni);

                }
            }
            i++;
        }

    }

}

class karinca extends canli {

    int kyiyenSayisi = 0;

    public karinca(String ad, int yas) {

        super(ad, yas);

    }

    @Override
    public void hastalıkKapv2(ArrayList<canli> canlilar) {

        for (canli canlilar1 : canlilar) {
            if (canlilar1 instanceof karincayiyen) {
                //i.canlı karncayiyen ise ++
                kyiyenSayisi++;
            }
        }
        this.hastalıkKapv2(canlilar);//Override oldugundan dolayı metodu tekrardan cagırıyorum.

    }

}

class virus implements Comparable<virus> {

    String ad;
    double bulasmaMiktari;
    double guc;

    public int compareTo(virus virusObj) {
        if (this instanceof covid_19 && virusObj instanceof covid_19) {
            return 1;
        } else if (this instanceof covid_20 && virusObj instanceof covid_20) {
            return 1;
        } else if (this instanceof covid_21 && virusObj instanceof covid_21) {
            return 1;
        } else {
            return 0;
        }

    }

    public virus(String ad, double bulasmaMiktari, double guc) {
        this.ad = ad;
        this.bulasmaMiktari = bulasmaMiktari;
        this.guc = guc;

    }

    public virus(virus virusObj) {
        virus yenivirus = new virus(virusObj) {

            @Override
            public void mutasyonaUgra(virus other) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public boolean hastaEdiyormu(canli other) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        };

    }

    public abstract void mutasyonaUgra(virus other);

    public abstract boolean hastaEdiyormu(canli other);

}

class covid_19 extends virus {

    public covid_19(String ad, double bulasmaMiktari, double guc) {
        super(ad, bulasmaMiktari, guc);
    }

    @Override
    public boolean hastaEdiyormu(canli other) {
        return other instanceof insan;

    }

    @Override
    public void mutasyonaUgra(virus other) {
        if (other instanceof covid_21) {
            this.guc = guc * 2;

        }
    }

}

class covid_20 extends virus {

    public covid_20(String ad, double bulasmaMiktari, double guc) {
        super(ad, bulasmaMiktari, guc);
    }

    @Override
    public boolean hastaEdiyormu(canli other) {//herkesi hasta edebiliyor
        return true;

    }

    @Override
    public void mutasyonaUgra(virus other) {

    }

}

class covid_21 extends virus {

    public covid_21(String ad, double bulasmaMiktari, double guc) {
        super(ad, bulasmaMiktari, guc);
    }

    @Override
    public boolean hastaEdiyormu(canli other) {
        return other instanceof karinca || other instanceof insan;
    }

    @Override
    public void mutasyonaUgra(virus other) {
        if (other instanceof covid_21) {
            this.guc = guc * 3;

        }

    }
}

public class Odev {

    public static void main(String[] args) {

    }

}
